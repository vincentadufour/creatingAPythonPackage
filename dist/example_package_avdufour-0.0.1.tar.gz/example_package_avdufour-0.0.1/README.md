# creatingAPythonPackage
CS3250 Activity 14 Learning how to create a Python Package

# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.